To know more about Data Synchronization feature of BMI08x read 'DataSync.md' file in 'sensorAPI/bmi08x' folder.

Short the INT1 and INT3 pins on the shuttle board before running the example.
(INT1 and INT3 are 2 pins which project on top of the BMI08x shuttle board)

* Works for both BMI085 and BMI088
* Update path where arm-none-eabi-gcc.exe exists to PATH environmental variable
* Command to run : mingw32-make TARGET=APP20 download
* In hterm, enable DTR signal to view output
* Various commands to run COINES examples : https://github.com/BoschSensortec/COINES/tree/master/template/c

