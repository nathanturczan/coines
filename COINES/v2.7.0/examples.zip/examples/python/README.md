# Running Python examples

- Install Python 3.x
- Run `pip install -r requirements.txt` to install `coinespy` and other dependencies
- Connect Application Board to PC and run `python <example.py>`

>> NOTE : Example will fail to run if Application Board USB driver is not installed.
